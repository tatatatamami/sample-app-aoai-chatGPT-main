"""Azure AI Foundry Agent integration module."""

from .client import FoundryClient

__all__ = ["FoundryClient"]
